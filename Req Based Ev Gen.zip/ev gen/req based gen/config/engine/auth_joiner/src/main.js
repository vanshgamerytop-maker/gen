// 9DEVS Auth Joiner
const fs = require("fs");
const fetch = require("node-fetch");
const config = require("../../../config.json").auth_joiner;
const path = require("path");
const { HttpsProxyAgent } = require('https-proxy-agent');

let proxies = [];
try {
  const proxyPath = path.join(__dirname, '../../../input/proxies.txt');
  proxies = fs.readFileSync(proxyPath, 'utf8').split(/\r?\n/).filter(p => p.trim() !== '');
} catch (e) {
  console.log('[9DEVS] Could not load proxies.txt. Will run without proxies.');
}

function getRandomProxyAgent() {
  if (proxies.length === 0) return undefined;
  let p = proxies[Math.floor(Math.random() * proxies.length)];
  if (!p.startsWith('http')) {
    if (p.includes('@')) {
       p = 'http://' + p;
    } else {
       const parts = p.split(':');
       if(parts.length === 4) {
           p = `http://${parts[0]}:${parts[1]}@${parts[2]}:${parts[3]}`;
       } else {
           p = 'http://' + p;
       }
    }
  }
  return new HttpsProxyAgent(p);
}

let i = 0;

(async () => {
  let filePath = path.join(__dirname, '../../../output/email_verified.txt');
  if (!fs.existsSync(filePath)) {
     filePath = path.join(__dirname, '../../../input/tokens.txt');
  }
  let cleanedFilePath = [];
  try {
     cleanedFilePath = fs.readFileSync(filePath, 'utf8').split(/\r?\n/);
  } catch(e) {
     console.log("[9DEVS] No tokens found in output/email_verified.txt or input/tokens.txt!");
     return;
  }
  const CHUNK_SIZE = 50; // Execute 50 requests concurrently
  for (let c = 0; c < cleanedFilePath.length; c += CHUNK_SIZE) {
    const chunk = cleanedFilePath.slice(c, c + CHUNK_SIZE);
    
    await Promise.all(chunk.map(async (rawToken) => {
      if (!rawToken) return;
      // Handle email:pass:token format
      const parts = rawToken.replace(/"/g, '').split(':');
      const token = parts.length >= 3 ? parts[2] : parts[0];
      
      try {
        const agent = getRandomProxyAgent();
        let response = await fetch(`https://discord.com/api/oauth2/authorize?client_id=${config.bot.id}&redirect_uri=http%3A%2F%2Flocalhost%3A3001&response_type=code&scope=identify%20email%20guilds.join`, { 
          "headers": { "authorization": token, "content-type": "application/json" }, 
          "body": "{\"permissions\":\"0\",\"authorize\":true}", 
          "method": "POST",
          "agent": agent
        });
        
        if (response.status === 429) {
          console.log(`[Rate Limit] OAuth Authorize rate limited for token ${token.substring(0, 15)}...`);
          return;
        } else if (response.status === 401) {
          console.log(`[Unauthorized] Invalid token ${token.substring(0, 15)}...`);
          return;
        }

        let data = await response.json();
        
        if (data.location) {
          // Do not use the proxy to connect to localhost!
          await fetch(data.location).then(x => x.json()).then(x => {
            if (x.joined) {
              i++;
              console.log(i + " - " + x.message);
            } else {
              console.log(`[Failed] ${x.message}`);
            }
          }).catch(err => { 
            console.log(`[Local Server Error] ${err.message}`);
          });
        } else {
            console.log(`[Error] No location redirect from Discord for token ${token.substring(0, 15)}...`);
        }
      } catch (err) { 
        console.log(`[Fetch Error] ${err.message}`);
      }
    }));
  }
  console.log("Finished submitting all tokens!");
})();