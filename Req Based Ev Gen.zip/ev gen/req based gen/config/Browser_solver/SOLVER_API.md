# Manthan Shop — Local hCaptcha Solver API

> **Base URL:** `http://localhost:5001`
> 
> The solver must be running before making any requests:
> ```
> python solver.py
> ```

---

## Authentication

The **v1 API** (GET-based) requires no authentication.

The **v2 API** (POST-based) accepts an `Authorization: Bearer <key>` header — currently ignored by the local solver but included for forward compatibility.

---

## Endpoints

### `GET /task/ping`
Health check — use this to verify the solver is up.

**Response**
```json
{ "status": "ok" }
```

---

## v1 API — GET-based *(used by `solver_client.py`)*

### `GET /solve`

Submit a new captcha task.

**Query Parameters**

| Parameter | Required | Description |
|---|---|---|
| `url` | ✅ | Page URL where the captcha appears (e.g. `https://discord.com`) |
| `sitekey` | ✅ | hCaptcha site key |
| `rqdata` | ❌ | Enterprise `rqdata` string (Discord requires this) |
| `user_agent` | ❌ | Browser user-agent to use for solving |
| `srv` | ❌ | Proxy `host:port` |
| `usr` | ❌ | Proxy username |
| `pw` | ❌ | Proxy password |

**Response** `200 OK`
```json
{ "taskid": "ab3xz" }
```

**Error Response** `400 / 500`
```json
{ "error": "URL parameter is required" }
```

---

### `GET /task/{taskid}`

Poll the result of a previously submitted task.

**Response — Pending**
```json
{ "status": "launching" }
{ "status": "loaded" }
{ "status": "monitoring" }
```

**Response — Solved** `200 OK`
```json
{
  "status": "success",
  "uuid": "P1_eyJ0eXAiOiJKV1Qi..."
}
```

**Response — Failed** `200 OK`
```json
{ "status": "error", "uuid": null }
```

**Response — Unknown ID** `200 OK`
```json
{ "status": "not_found", "uuid": null }
```

---

## v2 API — POST-based *(used by `Discord Joiner/solver_client.py`)*

### `POST /api/createTask`

Submit a new captcha task.

**Request Body** `Content-Type: application/json`

```json
{
  "url":        "https://discord.com",
  "sitekey":    "4c672d35-0701-42b2-88c3-78380b0db560",
  "rqdata":     "eyJ...",
  "user_agent": "Mozilla/5.0 ...",
  "proxy":      "http://user:pass@host:port"
}
```

| Field | Required | Description |
|---|---|---|
| `url` | ✅ | Page URL |
| `sitekey` | ✅ | hCaptcha site key |
| `rqdata` | ❌ | Enterprise rqdata |
| `user_agent` | ❌ | Browser UA |
| `proxy` | ❌ | Full proxy URL `http://user:pass@host:port` |

**Response** `202 Accepted`
```json
{ "taskId": "qr7mn" }
```

**Error Response** `400 / 500`
```json
{ "error": "url is required" }
```

---

### `GET /api/getResult/{taskId}`

Poll for the result of a submitted task.

**Response — Still solving**
```json
{ "status": "solving" }
```

**Response — Solved** `200 OK`
```json
{
  "status": "success",
  "solution": {
    "token": "P1_eyJ0eXAiOiJKV1Qi..."
  }
}
```

**Response — Failed** `200 OK`
```json
{
  "status": "error",
  "error": "Captcha solve failed or task not found"
}
```

---

## Status Reference

| Internal Status | v1 `status` | v2 `status` | Meaning |
|---|---|---|---|
| `not_ready` | `not_ready` | `solving` | Task registered, loop starting |
| `queued` | `queued` | `solving` | Queued for processing |
| `launching` | `launching` | `solving` | Browser opening |
| `loaded` | `loaded` | `solving` | Page loaded in browser |
| `monitoring` | `monitoring` | `solving` | Waiting for captcha completion |
| `success` | `success` | `success` | Token captured ✓ |
| `error` | `error` | `error` | Solve failed or timed out |
| `not_found` | `not_found` | `error` | Unknown task ID |

---

## Example — Python v1

```python
import requests, time

SERVER = "http://localhost:5001"

# 1. Submit
resp = requests.get(f"{SERVER}/solve", params={
    "url":      "https://discord.com",
    "sitekey":  "4c672d35-0701-42b2-88c3-78380b0db560",
    "rqdata":   "eyJ...",   # optional
})
taskid = resp.json()["taskid"]

# 2. Poll
while True:
    r = requests.get(f"{SERVER}/task/{taskid}").json()
    if r["status"] == "success":
        token = r["uuid"]
        print("Token:", token[:40])
        break
    if r["status"] == "error":
        print("Failed"); break
    time.sleep(2)
```

---

## Example — Python v2

```python
import requests, time

SERVER = "http://localhost:5001"

# 1. Submit
resp = requests.post(f"{SERVER}/api/createTask", json={
    "url":     "https://discord.com",
    "sitekey": "4c672d35-0701-42b2-88c3-78380b0db560",
    "rqdata":  "eyJ...",   # optional
})
task_id = resp.json()["taskId"]

# 2. Poll
while True:
    r = requests.get(f"{SERVER}/api/getResult/{task_id}").json()
    if r["status"] == "success":
        token = r["solution"]["token"]
        print("Token:", token[:40])
        break
    if r["status"] == "error":
        print("Failed"); break
    time.sleep(2)
```

---

## Notes

- **Timeout:** Tasks time out after **120 seconds** if no captcha token is received.
- **Concurrency:** Each task spawns its own browser window. Running many tasks simultaneously is heavy on RAM.
- **Mode:** If no NopeCHA key is set in `config/config.json`, the solver opens a browser window and waits for **manual** solving.
- **Completed tasks** are automatically pruned from memory after **5 minutes**.
- The solver token (`uuid` / `solution.token`) is a standard hCaptcha response string, ready to pass as `X-Captcha-Key` in Discord API requests.
