"""
solver.py  —  Manthan Shop  ·  Local hCaptcha Browser Solver
──────────────────────────────────────────────────────────────
• Flask REST server  (localhost:5002)
• Solves hCaptcha via browser  (NopeCHA auto  or  manual)
• Gradient terminal UI
• Supports both v1 (GET /solve) and v2 (POST /api/createTask) APIs
• Fully standalone — reads config from its own folder
"""

import asyncio
import base64
import json
import logging
import os
import platform
import random
import re
import shutil
import tempfile
import threading
import time
from urllib.parse import urlparse
import datetime
from pathlib import Path

# ── Silence Flask / Werkzeug HTTP access logs ────────────────────────────────
# Removes the  127.0.0.1 - - [date] "GET /... 200 -"  noise from the terminal.
logging.getLogger("werkzeug").setLevel(logging.ERROR)
logging.getLogger("werkzeug").propagate = False

from flask import Flask, request

import truedriver as td
from truedriver.cdp.fetch import HeaderEntry, RequestPattern, RequestStage
from truedriver.cdp.network import ResourceType

# ── All paths relative to THIS file ──────────────────────────────────────────
BASE_DIR = Path(__file__).parent.resolve()

# ─────────────────────────── Gradient UI ─────────────────────────────────────

_print_lock = threading.Lock()


def _gradient_text(text, c1, c2):
    length = max(1, len(text) - 1)
    result = []
    for i, ch in enumerate(text):
        r = int(c1[0] + (c2[0] - c1[0]) * i / length)
        g = int(c1[1] + (c2[1] - c1[1]) * i / length)
        b = int(c1[2] + (c2[2] - c1[2]) * i / length)
        result.append(f'\033[38;2;{r};{g};{b}m{ch}')
    result.append('\033[0m')
    return ''.join(result)


def _apply_gradient_block(lines, c1=(250, 5, 115), c2=(255, 100, 180)):
    total = len(lines)
    out = []
    for i, line in enumerate(lines):
        llen = max(1, len(line) - 1)
        row = []
        for j, ch in enumerate(line):
            t = ((i / max(1, total - 1)) + (j / llen)) / 2
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            row.append(f'\033[38;2;{r};{g};{b}m{ch}')
        row.append('\033[0m')
        out.append(''.join(row))
    return out


def show_interface():
    os.system('cls' if os.name == 'nt' else 'clear')
    logo = [
        '                                                              ',
        '  ███████╗ ██████╗ ██╗    ██╗   ██╗███████╗██████╗          ',
        '  ██╔════╝██╔═══██╗██║    ██║   ██║██╔════╝██╔══██╗         ',
        '  ███████╗██║   ██║██║    ██║   ██║█████╗  ██████╔╝         ',
        '  ╚════██║██║   ██║██║    ╚██╗ ██╔╝██╔══╝  ██╔══██╗         ',
        '  ███████║╚██████╔╝███████╗╚████╔╝ ███████╗██║  ██║         ',
        '  ╚══════╝ ╚═════╝ ╚══════╝ ╚═══╝  ╚══════╝╚═╝  ╚═╝         ',
        '                                                              ',
    ]
    print()
    try:
        tw = os.get_terminal_size().columns
    except OSError:
        tw = 90
    max_len = max(len(l) for l in logo)
    centered = [' ' * max(0, (tw - max_len) // 2) + l for l in logo]
    for line in _apply_gradient_block(centered, (250, 5, 115), (255, 100, 180)):
        print(line)
        time.sleep(0.03)
    tag = '✦  Manthan Shop  —  Local hCaptcha Solver  ✦'
    print(' ' * max(0, (tw - len(tag)) // 2) +
          _gradient_text(tag, (250, 5, 115), (255, 120, 200)))
    sub = 'Flask Server  •  NopeCHA / Manual  •  Async Browser  •  Port 5002'
    print(' ' * max(0, (tw - len(sub)) // 2) +
          _gradient_text(sub, (180, 5, 80), (220, 80, 150)))
    print()


def _ts():
    return datetime.datetime.now().strftime('%I:%M %p')


def log_event(level, message):
    tag = level.upper()
    _palette = {
        'SUCCESS': ((80, 255, 120),  (0, 200, 80)),
        'SOLVE':   ((160, 32, 240),  (200, 80, 255)),
        'ERROR':   ((255, 80, 80),   (220, 30, 30)),
        'INFO':    ((250, 5, 115),   (255, 100, 180)),
        'WARNING': ((255, 230, 60),  (240, 170, 0)),
        'CAPTCHA': ((255, 180, 50),  (255, 100, 0)),
        'VERSION': ((200, 200, 255), (140, 140, 220)),
        'SERVER':  ((80, 200, 255),  (0, 150, 255)),
        'TASK':    ((150, 255, 200), (0, 200, 150)),
    }
    _symbols = {
        'SUCCESS': '$', 'SOLVE': '$', 'ERROR': '!',
        'INFO': '+', 'WARNING': '¥', 'CAPTCHA': '~',
        'VERSION': 'Δ', 'SERVER': '⚡', 'TASK': '◈',
    }
    c1, c2 = _palette.get(tag, _palette['INFO'])
    sym    = _symbols.get(tag, tag)
    label  = _gradient_text(f'[{sym}]', c1, c2)
    ts_col = _gradient_text(f'[{_ts()}]', (80, 80, 110), (140, 140, 180))
    has_ansi = '\033[' in message or '\x1b[' in message
    if ':' in message and not has_ansi:
        k, v = message.split(':', 1)
        msg_col = (f'{_gradient_text(k.strip(), c1, c2)}'
                   f'{_gradient_text(":", (180,180,200),(120,120,150))} '
                   f'{_gradient_text(v.strip(), (180,180,200),(120,120,150))}')
    else:
        msg_col = _gradient_text(message, c1, c2) if not has_ansi else message
    with _print_lock:
        print(f'{ts_col} {label} > {msg_col}\033[0m')


def log_error(m):   log_event('ERROR',   m)
def log_success(m): log_event('SUCCESS', m)
def log_solve(m):   log_event('SOLVE',   m)
def log_info(m):    log_event('INFO',    m)
def log_warn(m):    log_event('WARNING', m)
def log_captcha(m): log_event('CAPTCHA', m)
def log_version(m): log_event('VERSION', m)
def log_server(m):  log_event('SERVER',  m)
def log_task(m):    log_event('TASK',    m)


# ─────────────────────────── Config ──────────────────────────────────────────
# All config lives in config.json (same folder as this file).
# Keys:
#   nopecha_key  — NopeCHA API key (leave "" for manual mode)
#   manual       — true forces manual mode even if key is set

def load_config() -> dict:
    # 1st priority: parent folder config.json  (worker/1/config.json)
    parent_cfg = BASE_DIR.parent / "config.json"
    # 2nd priority: own config.json  (Browser_solver/config.json)
    own_cfg    = BASE_DIR / "config.json"
    for cfg_path in (parent_cfg, own_cfg):
        try:
            if cfg_path.exists():
                data = json.loads(cfg_path.read_text(encoding="utf-8-sig"))
                return data
        except Exception as e:
            log_error(f"Failed to load {cfg_path.name}: {e}")
    return {}


_cfg = load_config()
NOPECHA_KEY = str(_cfg.get("nopecha_key", "")).strip()

# ─────────────────────────── Tasks store ─────────────────────────────────────

_TASK_TTL  = 300
tasks: dict = {}
_tasks_lock = threading.Lock()


def _set_task(taskid: str, data: dict):
    data["_ts"] = time.time()
    with _tasks_lock:
        tasks[taskid] = data
        _prune_tasks()


def _prune_tasks():
    now  = time.time()
    done = {"success", "error", "not_found"}
    stale = [k for k, v in tasks.items()
             if v.get("status") in done
             and now - v.get("_ts", now) > _TASK_TTL]
    for k in stale:
        del tasks[k]


def _get_task(taskid: str) -> dict:
    with _tasks_lock:
        entry = tasks.get(taskid)
    if entry is None:
        return {"status": "not_found", "uuid": None}
    return {k: v for k, v in entry.items() if k != "_ts"}


# ─────────────────────────── HTML template ───────────────────────────────────

HTML_TEMPLATE = """\
<!DOCTYPE html>
<html>
<head>
  <title>hCaptcha Solver</title>
  <script src="https://js.hcaptcha.com/1/api.js?onload=hcaptchaOnLoad" async defer></script>
</head>
<body>
  <div class="h-captcha" data-sitekey="SITE_KEY"></div>
</body>
</html>
"""

EXTENSION_DIR = str(BASE_DIR / "extension")


# ─────────────────────────── Helpers ─────────────────────────────────────────

def _random_task_id(length: int = 5) -> str:
    return "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=length))


def _safe_path_read(file_path: str, default: str = "") -> str:
    p = Path(file_path)
    if not p.is_absolute():
        p = BASE_DIR / p
    if not p.exists():
        log_warn(f"File not found: {p}")
        return default
    try:
        return p.read_text(encoding="utf-8")
    except Exception as e:
        log_error(f"Could not read {p}: {e}")
        return default


def _encode_base64(text: str) -> str:
    return base64.b64encode(text.encode("utf-8")).decode("utf-8")


# ─────────────────────────── Proxy-auth extension ────────────────────────────

def _create_proxy_auth_extension(username: str, password: str) -> str:
    """
    Write a tiny Chrome MV3 extension to a temp directory that silently
    provides proxy credentials via chrome.webRequest.onAuthRequired.

    MV3 requirements vs MV2:
    - manifest_version: 3
    - background.service_worker  (not background.scripts)
    - webRequestAuthProvider permission  (replaces webRequestBlocking)
    - host_permissions: ["<all_urls>"]  (moved out of permissions)
    - asyncBlocking + callback  (instead of synchronous return)

    Returns the temp directory path (caller must delete after browser stops).
    """
    ext_dir = tempfile.mkdtemp(prefix="proxy_auth_ext_")

    manifest = {
        "manifest_version": 3,
        "name": "Proxy Auth Helper",
        "version": "1.0",
        "permissions": [
            "webRequest",
            "webRequestAuthProvider",
        ],
        "host_permissions": ["<all_urls>"],
        "background": {
            "service_worker": "background.js",
        },
    }

    # MV3: asyncBlocking with callback — service worker provides creds before
    # Chrome ever considers showing the auth popup.
    background_js = (
        "chrome.webRequest.onAuthRequired.addListener(\n"
        "  function(details, callback) {\n"
        "    callback({\n"
        "      authCredentials: {\n"
        f"        username: {json.dumps(username)},\n"
        f"        password: {json.dumps(password)}\n"
        "      }\n"
        "    });\n"
        "  },\n"
        "  {urls: ['<all_urls>']},\n"
        "  ['asyncBlocking']\n"
        ");\n"
    )

    Path(ext_dir, "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    Path(ext_dir, "background.js").write_text(background_js, encoding="utf-8")
    return ext_dir


# ─────────────────────────── Browser args ────────────────────────────────────

def _build_browser_args(user_agent=None, proxy_config=None, extra_ext_dirs=None):
    cfg       = load_config()
    is_manual = cfg.get("manual", False) or not bool(NOPECHA_KEY)

    ext_path         = Path(EXTENSION_DIR)
    extension_exists = ext_path.exists() and (ext_path / "manifest.json").exists()
    if not extension_exists:
        log_warn(f"Extension not found at: {EXTENSION_DIR}")

    browser_args = [
        "--disable-infobars",
        "--disable-dev-shm-usage",
        "--window-size=800,620",
        "--window-position=100,80",
        "--no-first-run",
        "--lang=en-US",
        "--disable-background-networking",
        "--disable-background-timer-throttling",
        "--disable-renderer-backgrounding",
        "--remote-debugging-port=0",
        "--enable-unsafe-extension-debugging",
        "--no-sandbox",
        # ── RDP / server / VM compatibility ───────────────────────────────────
        # These prevent Chrome from crashing on machines with no real GPU
        # (RDP sessions, Windows Server, VPS, headless Linux).
        "--disable-gpu",
        "--disable-gpu-sandbox",
        "--disable-software-rasterizer",
        "--disable-gpu-compositing",
        "--disable-gl-drawing-for-tests",
        "--in-process-gpu",
        "--ignore-gpu-blocklist",
        "--use-gl=swiftshader",
        "--allow-running-insecure-content",
        "--disable-web-security",
        "--disable-features=IsolateOrigins,site-per-process",
        "--memory-pressure-off",
        "--max_old_space_size=512",
    ]

    # ── Collect all extension directories ─────────────────────────────────────
    all_ext_dirs = []
    if extension_exists and not is_manual:
        all_ext_dirs.append(str(EXTENSION_DIR))
        log_captcha("Auto-solve mode — NopeCHA extension loaded")
    else:
        mode = "manual (no key)" if not NOPECHA_KEY else "manual (config.json)"
        log_warn(f"Manual mode ({mode}) — solve captcha in the browser window")

    if extra_ext_dirs:
        all_ext_dirs.extend([d for d in extra_ext_dirs if d])

    if all_ext_dirs:
        dirs_str = ",".join(all_ext_dirs)
        browser_args.append(f"--disable-extensions-except={dirs_str}")
        browser_args.append(f"--load-extension={dirs_str}")
        browser_args.append(
            "--disable-features=DisableDisableExtensionsExceptCommandLineSwitch,"
            "DisableLoadExtensionCommandLineSwitch"
        )

    # ── Proxy server (host:port only — credentials go via extension) ──────────
    if proxy_config:
        srv = proxy_config.get("server", "")
        browser_args.append(f"--proxy-server={srv}")
        _host = srv.split("//")[-1] if "//" in srv else srv
        log_info(f"Browser proxy: {_host} | auth={'extension' if proxy_config.get('username') else 'none'}")

    normalized_ua = user_agent.replace("%20", " ") if user_agent else None
    return browser_args, normalized_ua


# ─────────────────────────── JS extraction ───────────────────────────────────

def _is_token_like(value: str) -> bool:
    if not isinstance(value, str):
        return False
    token = value.strip()
    if len(token) < 25:
        return False
    if re.search(r"[._-]", token):
        return True
    return bool(re.search(r"[A-Za-z0-9_-]{25,}", token))


async def get_hcaptcha_token(page):
    try:
        raw = await page.evaluate("hcaptcha.getResponse()")
        if isinstance(raw, tuple):
            raw = raw[0]
        if hasattr(raw, 'value'):
            return raw.value or ""
        if isinstance(raw, str):
            return raw
        return ""
    except Exception:
        return ""


# ─────────────────────────── Token polling ───────────────────────────────────

async def monitor_token(page, taskid: str, browser):
    start_time = time.time()
    last_log   = 0
    while True:
        try:
            token = await get_hcaptcha_token(page)
            if token and _is_token_like(token):
                log_solve(f"Task {taskid}: token captured: {token[:50]}...")
                _set_task(taskid, {"status": "success", "uuid": token})
                try:
                    await browser.stop()
                    log_task(f"Browser closed: task {taskid}")
                except Exception as e:
                    log_warn(f"Browser close error ({taskid}): {e}")
                return token

            elapsed = int(time.time() - start_time)
            if elapsed - last_log >= 15:
                last_log = elapsed
                log_task(f"Task {taskid}: waiting for captcha solve ({elapsed}s elapsed)")
        except Exception as e:
            log_error(f"monitor_token error ({taskid}): {e}")
        await asyncio.sleep(1)


# ─────────────────────────── Core solver ─────────────────────────────────────

async def solve_hcaptcha_async(taskid, sitekey, url,
                               user_agent=None, rqdata=None, proxy_config=None):
    browser       = None
    page          = None
    _proxy_ext    = None   # temp dir for proxy-auth extension — deleted in finally
    start         = time.time()
    target_base_url = url.split("?", 1)[0]

    template_body = HTML_TEMPLATE.replace("SITE_KEY", sitekey)
    hcap_html = _safe_path_read(
        "hcaptcha.html",
        default="<html><body>hcaptcha template not found</body></html>",
    )
    if rqdata:
        hcap_html = hcap_html.replace('Dr = t', f'Dr = "{rqdata}"')
        hcap_html = hcap_html.replace('Zr = t', f'Zr = "{rqdata}"')

    try:
        log_task(f"Task {taskid}: starting — {url}")
        _set_task(taskid, {"status": "launching", "uuid": None})

        # ── Create proxy-auth extension if proxy has credentials ──────────────
        # A Chrome extension handles webRequest.onAuthRequired synchronously,
        # so Chrome never shows the auth popup regardless of thread count.
        extra_ext_dirs = []
        if proxy_config and proxy_config.get("username") and proxy_config.get("password"):
            _proxy_ext = _create_proxy_auth_extension(
                proxy_config["username"], proxy_config["password"]
            )
            extra_ext_dirs.append(_proxy_ext)
            log_task(f"Task {taskid}: proxy-auth extension created")

        browser_args, normalized_ua = _build_browser_args(
            user_agent=user_agent, proxy_config=proxy_config, extra_ext_dirs=extra_ext_dirs
        )
        if proxy_config:
            log_task(f"Task {taskid}: browser launching WITH proxy: {proxy_config.get('server', '?')} | auth={'yes' if proxy_config.get('username') else 'no'}")
        else:
            log_task(f"Task {taskid}: browser launching WITHOUT proxy (direct connection)")
        browser = await asyncio.wait_for(
            td.start(
                user_agent=normalized_ua,
                proxy=proxy_config,
                browser_args=browser_args,
                sandbox=False,
                headless=False,
            ),
            timeout=45,
        )
        log_task(f"Task {taskid}: browser ready")
        page = await browser.get("about:blank")

        async def request_handler(event):
            """Intercept page/hcaptcha requests and serve local HTML templates."""
            request_url = event.request.url
            handled = False
            try:
                if request_url == url or request_url.startswith(target_base_url):
                    await page.send(td.cdp.fetch.fulfill_request(
                        request_id=event.request_id,
                        response_code=200,
                        response_headers=[HeaderEntry("Content-Type", "text/html; charset=utf-8")],
                        body=_encode_base64(template_body),
                    ))
                    handled = True
                elif "/static/hcaptcha.html" in request_url:
                    await page.send(td.cdp.fetch.fulfill_request(
                        request_id=event.request_id,
                        response_code=200,
                        response_headers=[HeaderEntry("Content-Type", "text/html; charset=utf-8")],
                        body=_encode_base64(hcap_html),
                    ))
                    handled = True
                if not handled:
                    await page.send(td.cdp.fetch.continue_request(
                        request_id=event.request_id
                    ))
            except Exception:
                # Silently swallow Invalid InterceptionId / state errors.
                pass

        handler_patterns = [
            RequestPattern(url_pattern=f"{target_base_url}*",
                           request_stage=RequestStage.REQUEST,
                           resource_type=ResourceType.DOCUMENT),
            RequestPattern(url_pattern="*static/hcaptcha.html*",
                           request_stage=RequestStage.REQUEST,
                           resource_type=ResourceType.DOCUMENT),
            RequestPattern(url_pattern="*api.js*",
                           request_stage=RequestStage.REQUEST,
                           resource_type=None),
        ]
        # Proxy credentials are embedded in --proxy-server at launch time.
        # handle_auth_requests=False keeps fetch interception for templates only.
        await page.send(td.cdp.fetch.enable(patterns=handler_patterns, handle_auth_requests=False))
        page.add_handler(td.cdp.fetch.RequestPaused, request_handler)
        log_task(f"Task {taskid}: fetch interception enabled") 

        log_task(f"Task {taskid}: navigating to page")
        await page.get(url, timeout=10)
        _set_task(taskid, {"status": "loaded", "uuid": None})
        log_captcha(f"Task {taskid}: page loaded — giving NopeCHA 3s to attach...")

        # NopeCHA extension needs a moment to attach its Chrome Debugger
        # and inject into the hCaptcha iframe before we start polling.
        await asyncio.sleep(3)

        token_task = asyncio.create_task(monitor_token(page, taskid, browser))
        _set_task(taskid, {"status": "monitoring", "uuid": None})

        try:
            uuid_result = await asyncio.wait_for(token_task, timeout=120)
            duration = round(time.time() - start, 2)
            log_success(f"Task {taskid}: solved in {duration}s")
            return uuid_result, duration
        except asyncio.TimeoutError:
            log_warn(f"Task {taskid}: timed out after 120s")
            _set_task(taskid, {"status": "error", "uuid": None})
            try:
                token_task.cancel()
            except Exception:
                pass
            return None, time.time() - start

    except Exception as e:
        log_error(f"Task {taskid}: error — {e}")
        _set_task(taskid, {"status": "error", "uuid": None})
        return None, time.time() - start

    finally:
        if page is not None:
            try:
                page.remove_handlers(td.cdp.fetch.RequestPaused, request_handler)
                await page.send(td.cdp.fetch.disable())
            except Exception:
                pass
        if browser is not None and _get_task(taskid).get("status") != "success":
            try:
                await browser.stop()
                log_task(f"Task {taskid}: browser closed (cleanup)")
            except Exception as e:
                log_warn(f"Task {taskid}: browser close error — {e}")
        # Delete the temp proxy-auth extension directory
        if _proxy_ext:
            try:
                shutil.rmtree(_proxy_ext, ignore_errors=True)
            except Exception:
                pass


# ─────────────────────────── Flask app ───────────────────────────────────────

app  = Flask(__name__)
loop = None


def run_event_loop():
    global loop
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        # ── Suppress harmless CDP race-condition noise ────────────────────────
        # truedriver schedules Connection.send() as background asyncio Tasks.
        # When a Fetch.continueRequest or continueWithAuth arrives after Chrome
        # already resolved that interception ID (very common with proxy auth +
        # page intercept running simultaneously), the Task raises:
        #   ProtocolException: Invalid InterceptionId  / Invalid state for ...
        # These are HARMLESS — the captcha still solves. We suppress them here
        # so they don't spam the terminal, while letting all real errors through.
        _CDP_NOISE = {
            "Invalid InterceptionId.",
            "Invalid state for continueInterceptedRequest",
        }

        def _exception_handler(lp, context):
            exc = context.get("exception")
            if exc is not None:
                exc_type = type(exc).__name__
                exc_msg  = str(exc)
                # Silence known-harmless CDP protocol errors only
                if exc_type == "ProtocolException" and any(n in exc_msg for n in _CDP_NOISE):
                    return  # swallow silently
            # All other exceptions go to the default handler (still visible)
            lp.default_exception_handler(context)

        loop.set_exception_handler(_exception_handler)
        loop.run_forever()
    except Exception as e:
        log_error(f"Event loop crashed: {e}")


threading.Thread(target=run_event_loop, daemon=True).start()


def parse_proxy_qs():
    """Parse proxy from GET query string:  ?srv=host:port&usr=u&pw=p"""
    srv = request.args.get("srv")
    if not srv:
        return None
    proxy_config = {"server": f"http://{srv}"}
    usr = request.args.get("usr")
    pw  = request.args.get("pw")
    if usr and pw:
        proxy_config["username"] = usr
        proxy_config["password"] = pw
    return proxy_config


def _wait_for_loop(taskid: str) -> bool:
    waited = 0
    while (loop is None or not loop.is_running()) and waited < 50:
        time.sleep(0.1)
        waited += 1
    if loop is None or not loop.is_running():
        log_error(f"Event loop not ready for task {taskid}")
        _set_task(taskid, {"status": "error", "uuid": None})
        return False
    return True


def _dispatch(taskid, sitekey, url, user_agent, rqdata, proxy_config) -> bool:
    try:
        asyncio.run_coroutine_threadsafe(
            solve_hcaptcha_async(taskid, sitekey, url,
                                 user_agent=user_agent,
                                 rqdata=rqdata,
                                 proxy_config=proxy_config),
            loop,
        )
        return True
    except Exception as e:
        log_error(f"Failed to schedule task {taskid}: {e}")
        _set_task(taskid, {"status": "error", "uuid": None})
        return False


# ── Health check ──────────────────────────────────────────────────────────────

@app.route("/task/ping", methods=["GET"])
def ping():
    return {"status": "ok"}


# ── v1 API  (GET-based) ───────────────────────────────────────────────────────

@app.route("/solve", methods=["GET"])
def solve():
    url     = request.args.get("url")
    sitekey = request.args.get("sitekey")
    if not url:     return {"error": "url is required"}, 400
    if not sitekey: return {"error": "sitekey is required"}, 400

    taskid = _random_task_id()
    _set_task(taskid, {"status": "not_ready", "uuid": None})
    if not _wait_for_loop(taskid):
        return {"taskid": taskid, "error": "Event loop not available"}, 500

    log_server(f"[v1] task {taskid} | sitekey {sitekey[:12]}...")
    user_agent   = request.args.get("user_agent")
    rqdata       = request.args.get("rqdata", "").replace(" ", "+")
    proxy_config = parse_proxy_qs()

    if not _dispatch(taskid, sitekey, url, user_agent, rqdata, proxy_config):
        return {"taskid": taskid, "error": "Failed to schedule"}, 500
    return {"taskid": taskid}


@app.route("/task/<taskid>", methods=["GET"])
def check_task(taskid):
    return _get_task(taskid)


# ── v2 API  (POST-based) ──────────────────────────────────────────────────────

@app.route("/api/createTask", methods=["POST"])
def api_create_task():
    body    = request.get_json(silent=True) or {}
    url     = body.get("url")
    sitekey = body.get("sitekey")
    if not url:     return {"error": "url is required"}, 400
    if not sitekey: return {"error": "sitekey is required"}, 400

    user_agent = body.get("user_agent", "")
    rqdata     = body.get("rqdata", "")
    proxy_raw  = body.get("proxy")
    proxy_config = None

    # ── Debug: log what proxy the client sent ───────────────────────────
    if proxy_raw:
        log_info(f"[DEBUG] Proxy received from client: {proxy_raw}")
        try:
            if "://" not in proxy_raw:
                proxy_raw = "http://" + proxy_raw
            from urllib.parse import urlparse
            p = urlparse(proxy_raw)
            # 'server' must be scheme://host:port ONLY — no embedded credentials
            proxy_config = {"server": f"http://{p.hostname}:{p.port}"}
            if p.username:
                proxy_config["username"] = p.username
            if p.password:
                proxy_config["password"] = p.password
            log_info(f"[DEBUG] Parsed proxy → server={proxy_config['server']} | auth={'yes' if p.username else 'no'}")
        except Exception as e:
            log_error(f"[DEBUG] Proxy parse failed: {e} | raw='{proxy_raw}' — browser will run direct")
            proxy_config = None
    else:
        log_info("[DEBUG] No proxy in task — browser will run direct")

    taskid = _random_task_id()
    _set_task(taskid, {"status": "queued", "uuid": None})
    if not _wait_for_loop(taskid):
        return {"taskId": taskid, "error": "Event loop not available"}, 500

    log_server(f"[v2] task {taskid} | sitekey {sitekey[:12]}...")
    if not _dispatch(taskid, sitekey, url, user_agent, rqdata, proxy_config):
        return {"taskId": taskid, "error": "Failed to schedule"}, 500
    return {"taskId": taskid}, 202


@app.route("/api/getResult/<taskid>", methods=["GET"])
def api_get_result(taskid):
    entry  = _get_task(taskid)
    status = entry.get("status", "not_found")
    uuid   = entry.get("uuid")

    if status in ("not_ready", "queued", "launching", "loaded", "monitoring"):
        out_status = "solving"
    elif status == "success":
        out_status = "success"
    else:
        out_status = "error"

    resp = {"status": out_status}
    if out_status == "success" and uuid:
        resp["solution"] = {"token": uuid}
    elif out_status == "error":
        resp["error"] = "Captcha solve failed or task not found"
    return resp


# ─────────────────────────── Entry point ─────────────────────────────────────

def run_flask():
    app.run(host="0.0.0.0", port=5002, debug=False, use_reloader=False)


if __name__ == "__main__":
    # show_interface() calls cls/clear — run it FIRST so it doesn't wipe key status logs
    show_interface()
    log_version("Manthan Shop  —  Local hCaptcha Solver")
    log_server("Listening on http://localhost:5002")
    log_info("v1  →  GET  /solve          GET  /task/<id>")
    log_info("v2  →  POST /api/createTask  GET  /api/getResult/<id>")
    print()

    # Write NopeCHA key into extension config — shown AFTER interface so it's always visible
    if NOPECHA_KEY:
        log_version(f"NopeCHA key loaded: {NOPECHA_KEY[:6]}... (len={len(NOPECHA_KEY)})")
        _ext_cfg = BASE_DIR / "extension" / "config.json"
        try:
            _payload = json.dumps({"api_key": NOPECHA_KEY}, indent=4)
            _ext_cfg.write_text(_payload, encoding="utf-8")
            # Verify write succeeded by reading it back
            _verify = json.loads(_ext_cfg.read_text(encoding="utf-8"))
            if _verify.get("api_key") == NOPECHA_KEY:
                log_success(f"NopeCHA key verified in extension/config.json")
            else:
                log_error("Extension config write FAILED — key mismatch after write!")
        except Exception as e:
            log_error(f"Could not write extension config: {e}")
    else:
        log_warn("No NopeCHA key found in config.json — running in manual mode")
        log_warn(f"Add 'nopecha_key' to: {(BASE_DIR.parent / 'config.json').resolve()}")
        log_warn("Set 'nopecha_key' in config.json to enable auto-solve")

    print()
    run_flask()
